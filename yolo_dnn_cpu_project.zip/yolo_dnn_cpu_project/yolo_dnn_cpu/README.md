# Image Processing + Object Detection with YOLO and DNN (CPU only, no CUDA)

Works on any laptop (tested design for Windows 11, AMD/Intel CPU).

## Files
| File | What it does |
|---|---|
| `setup_model.py` | One-time: download YOLOv8n and export to ONNX |
| `preprocess.py` | Image processing: gray, blur, equalize, sharpen, edges, threshold, contours |
| `yolo_detect.py` | YOLO detection (image / video / webcam) |
| `dnn_detect.py` | Same detection through OpenCV DNN (`cv2.dnn`) |
| `compare.py` | Speed comparison YOLO vs DNN |

## Steps (Windows PowerShell)
1. `python -m venv venv`
2. `venv\Scripts\activate`   (if blocked: `Set-ExecutionPolicy -Scope Process Bypass`)
3. `pip install torch torchvision`
4. `pip install -r requirements.txt`
5. `python setup_model.py`            (needs internet once; creates models\yolov8n.onnx)
6. Copy any photo to `images\test.jpg`
7. `python preprocess.py --source images\test.jpg`
8. `python yolo_detect.py --source images\test.jpg`
9. `python dnn_detect.py --source images\test.jpg`
10. Live webcam: `python yolo_detect.py --source 0 --imgsz 320`  or  `python dnn_detect.py --source 0 --size 320`
    (press q to quit)
11. Video file: `python dnn_detect.py --source images\video.mp4`
12. `python compare.py --source images\test.jpg`
13. Results are saved in `outputs\`.

## Tips
- Slow? Use `--imgsz 320` (YOLO) or `--size 320` (DNN).
- Too many/few boxes? Change `--conf` (0.5 = stricter, 0.2 = more detections).
- Webcam not opening? Try `--source 1`.
- Using `dnn_detect.py` at run time needs only opencv-python + numpy; PyTorch is only needed for `setup_model.py`
  and `yolo_detect.py`.
